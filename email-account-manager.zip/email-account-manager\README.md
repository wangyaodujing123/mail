# 📧 邮箱账号管理系统

一个完整的邮箱账号管理系统，支持批量导入、卡密生成、账号提取等功能。

## 🎯 功能特性

- ✅ **管理员登录** - 安全的JWT认证，默认账号: admin/admin123
- ✅ **批量导入** - 支持批量导入邮箱账号，自动去重
- ✅ **账号管理** - 管理员可以查看、删除账号
- ✅ **卡密生成** - 为账号生成唯一卡密，支持设置配额
- ✅ **配额管理** - 每张卡密可设置可提取次数（1次、5次、10次等）
- ✅ **账号提取** - 用户通过卡密提取账号密码
- ✅ **状态追踪** - 实时显示账号和卡密的使用状态
- ✅ **高级UI** - 现代化设计，响应式布局
- ✅ **Docker部署** - 一键部署到服务器

## 📋 系统架构

```
┌─────────────────────────────────────────┐
│         Nginx (反向代理)                 │
│         Port: 80                        │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│    Spring Boot 应用                     │
│    Port: 8080                           │
│  ┌──────────────────────────────────┐  │
│  │  REST API                        │  │
│  │  - /api/accounts/*               │  │
│  │  - /api/cards/*                  │  │
│  └──────────────────────────────────┘  │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│    MySQL 数据库                         │
│    Port: 3306                           │
│  ┌──────────────────────────────────┐  │
│  │  - accounts (账号表)             │  │
│  │  - cards (卡密表)                │  │
│  │  - users (用户表)                │  │
│  └──────────────────────────────────┘  │
└─────────────────────────────────────────┘
```

## 🚀 快速开始

### 前置要求
- Docker
- Docker Compose
- 现有的Nginx容器（可选，如果没有会自动创建）

### 部署步骤

1. **进入项目目录**
```bash
cd email-account-manager
```

2. **构建并启动容器**
```bash
docker-compose up -d
```

3. **等待服务启动**
```bash
docker-compose logs -f app
```

4. **配置现有Nginx（如果已有Nginx）**

如果你已经有运行中的Nginx容器，需要添加以下配置到你的Nginx配置文件：

```nginx
upstream email-app {
    server 127.0.0.1:8080;
}

server {
    listen 80;

    location /api {
        proxy_pass http://email-app/api;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location / {
        proxy_pass http://email-app;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

然后重启Nginx：
```bash
docker restart my-nginx
```

5. **访问系统**
- 登录界面: http://localhost/login.html
- 管理界面: http://localhost/
- 提取界面: http://localhost/extract.html

## 📖 使用指南

### 管理员操作

#### 1. 登录
1. 打开 http://localhost/login.html
2. 输入用户名: **admin**
3. 输入密码: **admin123**
4. 点击"🔓 登录"

#### 2. 导入账号
1. 登录后进入管理界面
2. 点击"📥 导入账号"标签
3. 粘贴邮箱列表（格式: email:password，一行一个）
4. 点击"📥 导入账号"按钮
5. 系统会自动去重，跳过已存在的账号

#### 3. 生成卡密

1. 点击"🎫 卡密管理"标签
2. 设置配额（可提取次数，默认1次）
3. 点击"生成卡密"按钮
4. 卡密会自动生成并显示在表格中

**说明**：卡密完全独立生成，用户使用卡密提取时会按顺序从数据库获取未被提取的账号

#### 4. 管理账号和卡密
- 查看所有账号和卡密的状态
- 查看卡密的配额使用情况（已使用/总配额）
- 删除不需要的账号或卡密
- 实时查看统计数据

### 用户操作

#### 提取账号
1. 打开提取界面 http://localhost/extract.html
2. 输入卡密
3. 点击"🔓 提取账号"
4. 获得邮箱和密码
5. 点击"复制"按钮复制到剪贴板

## 🔌 API 文档

### 账号管理 API

#### 导入账号
```
POST /api/accounts/import
Content-Type: application/json

{
  "content": "email1:password1\nemail2:password2"
}

Response:
{
  "code": 200,
  "message": "导入成功",
  "data": {
    "imported": 2,
    "accounts": [...]
  }
}
```

#### 获取所有账号
```
GET /api/accounts/list

Response:
{
  "code": 200,
  "message": "Success",
  "data": [...]
}
```

#### 获取统计信息
```
GET /api/accounts/stats

Response:
{
  "code": 200,
  "message": "Success",
  "data": {
    "unextracted": 10,
    "extracted": 5,
    "total": 15
  }
}
```

### 卡密管理 API

#### 生成卡密
```
POST /api/cards/generate
Content-Type: application/json

{
  "quota": 1
}

Response:
{
  "code": 200,
  "message": "卡密生成成功",
  "data": {
    "id": 1,
    "cardCode": "ABCD1234EFGH5678",
    "accountId": null,
    "quota": 1,
    "usedQuota": 0,
    "status": 0,
    "createdAt": "2024-01-01T12:00:00"
  }
}
```

#### 提取账号
```
POST /api/cards/extract
Content-Type: application/json

{
  "cardCode": "ABCD1234EFGH5678",
  "username": "user"
}

Response:
{
  "code": 200,
  "message": "提取成功",
  "data": {
    "id": 1,
    "email": "test@hotmail.com",
    "password": "password123",
    "status": 1,
    "extractedAt": "2024-01-01T12:00:00"
  }
}
```

**说明**：
- 卡密完全独立，不关联任何账号
- 提取时按顺序从数据库获取第一个未被提取的账号（status=0）
- 每次提取会消耗卡密的一个配额
- 当配额用完时，卡密自动标记为已使用

## 📊 数据库表结构

### accounts 表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| email | VARCHAR | 邮箱地址 |
| password | VARCHAR | 密码 |
| status | INT | 状态 (0=未提取, 1=已提取) |
| created_at | DATETIME | 创建时间 |
| extracted_at | DATETIME | 提取时间 |
| extracted_by | VARCHAR | 提取者 |

### cards 表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| card_code | VARCHAR | 卡密 |
| account_id | BIGINT | 账号ID |
| status | INT | 状态 (0=未使用, 1=已使用) |
| created_at | DATETIME | 创建时间 |
| used_at | DATETIME | 使用时间 |
| used_by | VARCHAR | 使用者 |

## 🔧 常见问题

### Q: 如何修改数据库密码？
A: 修改 `docker-compose.yml` 中的 `MYSQL_ROOT_PASSWORD` 和 `SPRING_DATASOURCE_PASSWORD`

### Q: 如何查看日志？
A: 运行 `docker-compose logs -f app`

### Q: 如何停止服务？
A: 运行 `docker-compose down`

### Q: 如何重启服务？
A: 运行 `docker-compose restart`

## 📝 许可证

MIT License

