package com.email.service;

import com.email.dto.AccountDTO;
import com.email.dto.CardDTO;
import com.email.entity.Account;
import com.email.entity.Card;
import com.email.repository.CardRepository;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CardService {
    @Autowired
    private CardRepository cardRepository;

    @Autowired
    private AccountService accountService;

    public CardDTO generateCard(Integer quota) {
        String cardCode = generateCardCode();
        Card card = new Card();
        card.setCardCode(cardCode);
        card.setAccount(null); // 卡密独立生成，不关联账号
        card.setStatus(0);
        card.setQuota(quota != null ? quota : 1);
        card.setUsedQuota(0);

        Card saved = cardRepository.save(card);
        return convertToDTO(saved);
    }



    public AccountDTO extractAccountByCard(String cardCode, String username) {
        Card card = cardRepository.findByCardCode(cardCode).orElse(null);
        if (card == null) {
            return null;
        }

        // 检查卡密状态
        if (card.getStatus() == 1) {
            return null; // 卡密已使用
        }

        // 检查配额
        if (card.getUsedQuota() >= card.getQuota()) {
            return null; // 配额已用完
        }

        // 从数据库按顺序获取一个未被提取的账号
        Account account = accountService.getFirstUnextractedAccount();
        if (account == null) {
            return null; // 没有可用账号
        }

        // 增加已使用配额
        card.setUsedQuota(card.getUsedQuota() + 1);

        // 如果配额用完，标记卡密为已使用
        if (card.getUsedQuota() >= card.getQuota()) {
            card.setStatus(1);
            card.setUsedAt(LocalDateTime.now());
            card.setUsedBy(username);
        }

        cardRepository.save(card);

        // 标记账号为已提取
        accountService.markAsExtracted(account.getId(), username);

        return accountService.convertToDTO(account);
    }



    public List<CardDTO> getUnusedCards() {
        return cardRepository.findByStatus(0).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<CardDTO> getAllCards() {
        return cardRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public void deleteCard(Long id) {
        cardRepository.deleteById(id);
    }

    public long getUnusedCount() {
        return cardRepository.countByStatus(0);
    }

    public long getUsedCount() {
        return cardRepository.countByStatus(1);
    }

    private String generateCardCode() {
        return RandomStringUtils.randomAlphanumeric(16).toUpperCase();
    }

    private CardDTO convertToDTO(Card card) {
        CardDTO dto = new CardDTO();
        dto.setId(card.getId());
        dto.setCardCode(card.getCardCode());
        dto.setAccountId(card.getAccount() != null ? card.getAccount().getId() : null);
        dto.setStatus(card.getStatus());
        dto.setCreatedAt(card.getCreatedAt());
        dto.setUsedAt(card.getUsedAt());
        dto.setUsedBy(card.getUsedBy());
        dto.setQuota(card.getQuota());
        dto.setUsedQuota(card.getUsedQuota());
        return dto;
    }
}

