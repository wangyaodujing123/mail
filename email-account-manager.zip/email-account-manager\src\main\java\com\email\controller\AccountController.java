package com.email.controller;

import com.email.dto.AccountDTO;
import com.email.dto.ApiResponse;
import com.email.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/accounts")
@CrossOrigin(origins = "*")
public class AccountController {
    @Autowired
    private AccountService accountService;

    @PostMapping("/import")
    public ApiResponse<Map<String, Object>> importAccounts(@RequestBody Map<String, String> request) {
        String content = request.get("content");
        List<String> lines = List.of(content.split("\n"));
        List<AccountDTO> imported = accountService.importAccounts(lines);
        
        Map<String, Object> result = Map.of(
                "imported", imported.size(),
                "accounts", imported
        );
        return ApiResponse.success("导入成功", result);
    }

    @GetMapping("/list")
    public ApiResponse<List<AccountDTO>> getAllAccounts() {
        return ApiResponse.success(accountService.getAllAccounts());
    }

    @GetMapping("/unextracted")
    public ApiResponse<List<AccountDTO>> getUnextractedAccounts() {
        return ApiResponse.success(accountService.getUnextractedAccounts());
    }

    @GetMapping("/{id}")
    public ApiResponse<AccountDTO> getAccountById(@PathVariable Long id) {
        AccountDTO account = accountService.getAccountById(id);
        if (account == null) {
            return ApiResponse.error(404, "账号不存在");
        }
        return ApiResponse.success(account);
    }

    @DeleteMapping("/{id}")
    public ApiResponse<String> deleteAccount(@PathVariable Long id) {
        accountService.deleteAccount(id);
        return ApiResponse.success("删除成功");
    }

    @GetMapping("/stats")
    public ApiResponse<Map<String, Long>> getStats() {
        Map<String, Long> stats = Map.of(
                "unextracted", accountService.getUnextractedCount(),
                "extracted", accountService.getExtractedCount(),
                "total", accountService.getUnextractedCount() + accountService.getExtractedCount()
        );
        return ApiResponse.success(stats);
    }
}

