package com.email.service;

import com.email.dto.AccountDTO;
import com.email.entity.Account;
import com.email.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountService {
    @Autowired
    private AccountRepository accountRepository;

    public AccountDTO addAccount(String email, String password) {
        Account account = new Account();
        account.setEmail(email);
        account.setPassword(password);
        account.setStatus(0);
        Account saved = accountRepository.save(account);
        return convertToDTO(saved);
    }

    public List<AccountDTO> importAccounts(List<String> accountLines) {
        List<AccountDTO> imported = new java.util.ArrayList<>();
        List<String> duplicates = new java.util.ArrayList<>();

        for (String line : accountLines) {
            if (line.trim().isEmpty()) continue;

            String[] parts = line.split(":");
            if (parts.length == 2) {
                String email = parts[0].trim();
                String password = parts[1].trim();

                if (accountRepository.findByEmail(email).isPresent()) {
                    duplicates.add(email);
                } else {
                    imported.add(addAccount(email, password));
                }
            }
        }

        // 存储重复信息供前端显示
        if (!duplicates.isEmpty()) {
            System.out.println("跳过重复账号: " + duplicates);
        }

        return imported;
    }

    public AccountDTO extractAccount(Long cardId, String username) {
        // 这个方法会在CardService中调用
        return null;
    }

    public Account getFirstUnextractedAccount() {
        List<Account> accounts = accountRepository.findByStatus(0);
        return accounts.isEmpty() ? null : accounts.get(0);
    }

    public List<AccountDTO> getUnextractedAccounts() {
        return accountRepository.findByStatus(0).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<AccountDTO> getAllAccounts() {
        return accountRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public AccountDTO getAccountById(Long id) {
        return accountRepository.findById(id)
                .map(this::convertToDTO)
                .orElse(null);
    }

    public void deleteAccount(Long id) {
        accountRepository.deleteById(id);
    }

    public long getUnextractedCount() {
        return accountRepository.countByStatus(0);
    }

    public long getExtractedCount() {
        return accountRepository.countByStatus(1);
    }

    protected AccountDTO convertToDTO(Account account) {
        AccountDTO dto = new AccountDTO();
        dto.setId(account.getId());
        dto.setEmail(account.getEmail());
        dto.setPassword(account.getPassword());
        dto.setStatus(account.getStatus());
        dto.setCreatedAt(account.getCreatedAt());
        dto.setExtractedAt(account.getExtractedAt());
        dto.setExtractedBy(account.getExtractedBy());
        return dto;
    }

    protected Account markAsExtracted(Long accountId, String username) {
        Account account = accountRepository.findById(accountId).orElse(null);
        if (account != null) {
            account.setStatus(1);
            account.setExtractedAt(LocalDateTime.now());
            account.setExtractedBy(username);
            return accountRepository.save(account);
        }
        return null;
    }
}

