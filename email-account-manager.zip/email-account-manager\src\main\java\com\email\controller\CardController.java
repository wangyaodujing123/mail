package com.email.controller;

import com.email.dto.AccountDTO;
import com.email.dto.ApiResponse;
import com.email.dto.CardDTO;
import com.email.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cards")
@CrossOrigin(origins = "*")
public class CardController {
    @Autowired
    private CardService cardService;

    @PostMapping("/generate")
    public ApiResponse<CardDTO> generateCard(@RequestBody Map<String, Object> request) {
        Integer quota = request.containsKey("quota") ? ((Number) request.get("quota")).intValue() : 1;
        CardDTO card = cardService.generateCard(quota);
        return ApiResponse.success("卡密生成成功", card);
    }



    @PostMapping("/extract")
    public ApiResponse<AccountDTO> extractAccount(@RequestBody Map<String, String> request) {
        String cardCode = request.get("cardCode");
        String username = request.getOrDefault("username", "anonymous");
        
        AccountDTO account = cardService.extractAccountByCard(cardCode, username);
        if (account == null) {
            return ApiResponse.error(400, "卡密无效或已使用");
        }
        return ApiResponse.success("提取成功", account);
    }

    @GetMapping("/list")
    public ApiResponse<List<CardDTO>> getAllCards() {
        return ApiResponse.success(cardService.getAllCards());
    }

    @GetMapping("/unused")
    public ApiResponse<List<CardDTO>> getUnusedCards() {
        return ApiResponse.success(cardService.getUnusedCards());
    }

    @GetMapping("/account/{accountId}")
    public ApiResponse<List<CardDTO>> getCardsByAccountId(@PathVariable Long accountId) {
        return ApiResponse.success(cardService.getCardsByAccountId(accountId));
    }

    @DeleteMapping("/{id}")
    public ApiResponse<String> deleteCard(@PathVariable Long id) {
        cardService.deleteCard(id);
        return ApiResponse.success("删除成功");
    }

    @GetMapping("/stats")
    public ApiResponse<Map<String, Long>> getStats() {
        Map<String, Long> stats = Map.of(
                "unused", cardService.getUnusedCount(),
                "used", cardService.getUsedCount(),
                "total", cardService.getUnusedCount() + cardService.getUsedCount()
        );
        return ApiResponse.success(stats);
    }
}

