package com.email.service;

import com.email.dto.LoginRequest;
import com.email.dto.LoginResponse;
import com.email.entity.User;
import com.email.repository.UserRepository;
import com.email.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public LoginResponse login(LoginRequest request) {
        Optional<User> user = userRepository.findByUsername(request.getUsername());
        
        if (!user.isPresent()) {
            return null;
        }
        
        User u = user.get();
        if (!passwordEncoder.matches(request.getPassword(), u.getPassword())) {
            return null;
        }
        
        String token = jwtUtil.generateToken(u.getUsername(), u.getRole());
        LoginResponse response = new LoginResponse();
        response.setToken(token);
        response.setUsername(u.getUsername());
        response.setRole(u.getRole());
        
        return response;
    }

    public void initDefaultAdmin() {
        if (!userRepository.findByUsername("admin").isPresent()) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole("admin");
            admin.setCreatedAt(LocalDateTime.now());
            userRepository.save(admin);
        }
    }
}

